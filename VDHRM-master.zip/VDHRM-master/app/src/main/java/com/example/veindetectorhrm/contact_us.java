package com.example.veindetectorhrm;

import android.app.AlertDialog;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;


public class contact_us extends Fragment {

    AppCompatEditText email,msg;
    AppCompatButton sendmsg;
    AlertDialog alertDialog;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_contact_us, container, false);
        alertDialog = new AlertDialog.Builder(getActivity()).create();
        email= (AppCompatEditText)view.findViewById(R.id.email_aboutus);
        msg=(AppCompatEditText)view.findViewById(R.id.msg_aboutus);
        sendmsg=(AppCompatButton)view.findViewById(R.id.aboutus_submit_btn);

        sendmsg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(email.getText().toString().isEmpty() || msg.getText().toString().isEmpty()){
                    alertDialog.setMessage("Both fields are required");
                    alertDialog.show();
                }else{
                    Toast.makeText(getActivity(),"Thank you for your feedback",Toast.LENGTH_LONG).show();
                    email.getText().clear();
                    msg.getText().clear();
                }
            }
        });

        return view;
    }


}
