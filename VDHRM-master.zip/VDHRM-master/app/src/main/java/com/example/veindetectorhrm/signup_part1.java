package com.example.veindetectorhrm;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.prefs.Preferences;

import static android.support.constraint.Constraints.TAG;


public class signup_part1 extends Fragment  {
    AlertDialog alertDialog;
    AppCompatButton signup_continue;
    AppCompatEditText signupUsernameEditetxt,signupEmailEditetxt,signupPhonenumEdittext;
    TextInputLayout signupUsernameLayout,signupEmailLayout,signupPhonenumLayout;
    Spinner spinner_role;
    private static final String[] roles = {"User", "Doctor"};

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_signup_part1, container, false);

        //---------------object reference----------
        alertDialog = new AlertDialog.Builder(getActivity()).create();
        spinner_role =(Spinner)view.findViewById(R.id.spinner);
        signupUsernameEditetxt=(AppCompatEditText)view.findViewById(R.id.signup_username_edittext);
        signupEmailEditetxt=(AppCompatEditText)view.findViewById(R.id.signup_email_edittext);
        signupPhonenumEdittext=(AppCompatEditText)view.findViewById(R.id.signup_phonenum_edittext);
        signupUsernameLayout=(TextInputLayout)view.findViewById(R.id.signup_username_layout);
        signupEmailLayout=(TextInputLayout)view.findViewById(R.id.signup_email_layout);
        signupPhonenumLayout=(TextInputLayout)view.findViewById(R.id.signup_phonenum_layout);

        //--------------editetxt-counter-handling--------------
        //username
        signupUsernameLayout.setCounterEnabled(true);
        signupUsernameLayout.setCounterMaxLength(12);
        //email
        signupEmailLayout.setCounterEnabled(true);
        signupEmailLayout.setCounterMaxLength(25);
        //phone
        signupPhonenumLayout.setCounterEnabled(true);
        signupPhonenumLayout.setCounterMaxLength(10);


        //-----spinner initialization---------------
        ArrayAdapter<String> adapter_option=new ArrayAdapter<String>(this.getActivity(),android.R.layout.simple_spinner_item,roles);
        adapter_option.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_role.setAdapter(adapter_option);
        spinner_role.setPrompt("Select a role");

        spinner_role.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getContext());
                SharedPreferences.Editor editor = preferences.edit();
                if(roles[position] == "User"){
                    editor.putInt("role",1);
                    editor.apply();
                }else
                {
                    editor.putInt("role",2);
                    editor.apply();
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        //-----------------------
        signup_continue = (AppCompatButton) view.findViewById(R.id.signup_btn1);
        signup_continue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validate()) {
                    String userName = signupUsernameEditetxt.getText().toString();
                    String userEmail = signupEmailEditetxt.getText().toString();
                    String userPhone = signupPhonenumEdittext.getText().toString();
                    SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getContext());
                    int role = preferences.getInt("role", 0);
                    FragmentManager fragmentManager = getFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    Bundle details_part1 = new Bundle();

                    details_part1.putString("username", userName);
                    details_part1.putString("useremail", userEmail);
                    details_part1.putString("userphone", userPhone);

                    if (role == 1) {
                        details_part1.putString("type", "user");
                        signup_part2 signupPart2 = new signup_part2();
                        signupPart2.setArguments(details_part1);
                        fragmentTransaction.replace(R.id.fragment_container, signupPart2);
                        fragmentTransaction.addToBackStack(null);
                        fragmentTransaction.commit();
                    } else {
                        details_part1.putString("type", "doctor");
                        signup_doctor signupDoctor = new signup_doctor();
                        signupDoctor.setArguments(details_part1);
                        fragmentTransaction.replace(R.id.fragment_container, signupDoctor);
                        fragmentTransaction.addToBackStack(null);
                        fragmentTransaction.commit();
                    }

                }
            }

        });

    return view;
    }




    private boolean validate() {
        if(signupUsernameEditetxt.getText().toString().isEmpty() ||
                signupEmailEditetxt.getText().toString().isEmpty() ||
                signupPhonenumEdittext.getText().toString().isEmpty() ){
            alertDialog.setMessage("All fields are required");
            alertDialog.show();
            return false;

        }else {
            return true;
        }
    }


}



