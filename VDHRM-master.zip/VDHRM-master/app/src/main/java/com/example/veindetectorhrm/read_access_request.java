package com.example.veindetectorhrm;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobile.client.Callback;
import com.amazonaws.mobile.client.UserStateDetails;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferService;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;

import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.S3ClientOptions;
import com.amazonaws.services.s3.AmazonS3Client.*;
import com.amazonaws.services.s3.internal.Constants;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ListObjectsV2Request;
import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.regions.Regions;


import java.io.File;
import java.util.ArrayList;
import java.util.List;


public class read_access_request extends Fragment {
    private static final int PERMISSION_REQUEST_CODE = 1;
    AppCompatButton btn;
    Context context = this.getActivity();
    AppCompatEditText phoneNum;
    String phone;
    AlertDialog alertDialog;
    Bundle info;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_read_access_request, container, false);
        alertDialog = new AlertDialog.Builder(getActivity()).create();
        phoneNum=(AppCompatEditText)view.findViewById(R.id.request_phoneNumber);

        btn = (AppCompatButton) view.findViewById(R.id.request_access_btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(phoneNum.getText().toString().isEmpty()){
                    phone = "nothing";
                }else{
                    phone = phoneNum.getText().toString();
                    if(phone.length()!= 10){
                        alertDialog.setMessage("Invalid Phone Number");
                        alertDialog.show();
                        phoneNum.getText().clear();
                        phoneNum.setFocusable(true);
                    }
                }
                int result = ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_PHONE_STATE);
                if(result == PackageManager.PERMISSION_GRANTED) {
                    createReport(info);
                }else {
                    permissionRequest();

                    }
                }

        });
        return view;
    }

    private void permissionRequest() {
        requestPermissions( new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
    }

    private void createReport(Bundle info) {
        Bundle phonenum = new Bundle();
        phonenum.putString("phone", phone);
                read_access_report read_access_report = new read_access_report();
                read_access_report.setArguments(phonenum);
                FragmentManager fragmentManager = getFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.homepage_frame_container, read_access_report);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();

        }

    //triggered after the request to access storage is granted. like an intent listener.
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.d("value", "Permission Granted, Now you can use local drive .");
                    createReport(info);
                } else {
                    alertDialog.setMessage("Without storage permission you cannot use this feature");
                    alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            alertDialog.dismiss();
                            phoneNum.getText().clear();
                        }
                    });
                   alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Set permission", new DialogInterface.OnClickListener() {
                       @Override
                       public void onClick(DialogInterface dialogInterface, int i) {
                           permissionRequest();
                       }
                   });
                   alertDialog.show();

                }
                break;
        }
    }



}



