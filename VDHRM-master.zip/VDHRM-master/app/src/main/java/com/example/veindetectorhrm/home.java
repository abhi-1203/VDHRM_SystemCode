package com.example.veindetectorhrm;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


public class home extends Fragment {
  TextView home_name;
  String uname,data;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=  inflater.inflate(R.layout.fragment_home, container, false);
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getContext());
        uname = preferences.getString("uname"," ");
        data= "Hello, "+uname;
        home_name=(TextView)view.findViewById(R.id.home_fragment1);
        home_name.setText(data);

    return view;
    }



}
