package com.example.veindetectorhrm;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class generateReport extends AsyncTask<String, Void, String> {

    @SuppressLint("StaticFieldLeak")
    Context ctx;
    private ProgressDialog Dialog ;
    private AlertDialog alertDialog;

    generateReport(Context context){
        ctx=context;
    };


    @Override
    protected void onPreExecute() {
        alertDialog = new AlertDialog.Builder(ctx).create();
        Dialog = new ProgressDialog(ctx);
        Dialog.setMessage("Generating...");
        Dialog.setIndeterminate(false);
        Dialog.setCancelable(false);
        Dialog.show();


        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... params) {
        String post_data=null;
        String type= params[0];
        String login_url = "https://vdhrm.000webhostapp.com/reportGen.php";

        if (type.equals("generateReport")){
            try {
                String DocID= params[1];
                String uEmail= params[2];
                String uName= params[3];
                String uPhNumber= params[4];
                String uAge= params[5];
                String TestFor= params[6];
                String Problem = params[7];
                String Desc = params[8];

                URL url = new URL(login_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, StandardCharsets.UTF_8));
                post_data = URLEncoder.encode("DocID", "UTF-8")+"="+URLEncoder.encode(DocID, "UTF-8")+"&"
                        +URLEncoder.encode("uEmail", "UTF-8")+"="+URLEncoder.encode(uEmail, "UTF-8")+"&"
                        +URLEncoder.encode("uName", "UTF-8")+"="+URLEncoder.encode(uName, "UTF-8")+"&"
                        +URLEncoder.encode("uPhNumber", "UTF-8")+"="+URLEncoder.encode(uPhNumber, "UTF-8")+"&"
                        +URLEncoder.encode("uAge", "UTF-8")+"="+URLEncoder.encode(uAge, "UTF-8")+"&"
                        +URLEncoder.encode("TestFor", "UTF-8")+"="+URLEncoder.encode(TestFor, "UTF-8")+ "&"
                        +URLEncoder.encode("Uproblem", "UTF-8")+"="+URLEncoder.encode(Problem, "UTF-8")+ "&"
                        +URLEncoder.encode("uDesc", "UTF-8")+"="+URLEncoder.encode(Desc, "UTF-8");


                if(post_data!=null) {

                    bufferedWriter.write(post_data);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    outputStream.close();
                    InputStream inputStream = httpURLConnection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.ISO_8859_1));

                    StringBuilder sb = new StringBuilder();
                    for (int c; (c = bufferedReader.read()) >= 0; )
                        sb.append((char) c);
                    String response = sb.toString();
                    Log.d("Res", "response from json: " + response);
                    bufferedReader.close();
                    inputStream.close();
                    httpURLConnection.disconnect();
                    JSONObject myResponse = new JSONObject(response);
                    Log.d("Res", "Result after Reading JSON Response: ");
                    //Log.d("tag","url- "+myResponse.getString("url"))
                    if (myResponse.getString("status").equals("200")) {
                        Log.d("SUCCESS", "Generated report Success.");
                        Log.d("Res", "Report Details: \n");
                        Log.d("Res", "DocID: " + myResponse.getString("DoctorID"));
                        Log.d("Res", "Test Type: " + myResponse.getString("TestType"));
                        Log.d("Res", "Report ID: " + myResponse.getString("ReportID"));
                        Log.d("Res", "DownloadLink: " + myResponse.getString("DownloadLink"));

                        return myResponse.toString();
                    } else {
                        Log.d("ERROR", "Report could not be generated. Try again later.\n");
                        return myResponse.getString("message");
                    }
                }
                else{
                    Log.d("ERROR", "No Data received. Please enter Patient's details and try again.\n");
                    return null;
                }

            } catch (MalformedURLException e) {
                Log.d("URLERROR","URL not found.");
                e.printStackTrace();
            } catch (IOException e) {
                Log.d("URLERROR","Connection cannot be performed. URL cannot be opened.");
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return null;
    }



    @Override
    protected void onPostExecute(String response) {

        Log.d("Resp","Response from server: "+response);
        Dialog.dismiss();
        try {
            JSONObject myResponses = new JSONObject(response);
            if(myResponses.getString("status").equals("200")) {
                fileHandler fileBT = new fileHandler(ctx);
                fileBT.listPaired(response);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        alertDialog.setMessage("Report generated successfully");
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                AppCompatActivity activity= (AppCompatActivity)ctx;
               activity.getSupportFragmentManager().beginTransaction().addToBackStack(null).replace(R.id.homepage_frame_container,new generate_report_part_1()).commit();
            }
        });
        alertDialog.show();
        super.onPostExecute(response);
    }

}

