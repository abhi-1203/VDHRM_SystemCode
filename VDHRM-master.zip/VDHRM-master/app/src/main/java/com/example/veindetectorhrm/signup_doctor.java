package com.example.veindetectorhrm;

import android.app.AlertDialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class signup_doctor extends Fragment {
    AlertDialog alertDialog;
    AppCompatButton doc_details_btn;
    TextInputLayout signupHnameLayout,signupHcodeLayout,signupHlocationLayout,signupSpecializationLayout;
    AppCompatEditText signupHnameEdittext, signupHcodeEdittext, signupHlocationEdittext,signupSpecializationEdittext;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View inflate = inflater.inflate(R.layout.fragment_signup_doctor, container, false);
        //--data from previous fragment--
        Bundle signup_doc_2 = this.getArguments();


        //----referencing objects------
        alertDialog = new AlertDialog.Builder(getActivity()).create();
        signupHnameLayout =(TextInputLayout)inflate.findViewById(R.id.signup_hname_layout);
        signupHcodeLayout=(TextInputLayout)inflate.findViewById(R.id.signup_hcode_layout);
        signupHlocationLayout=(TextInputLayout)inflate.findViewById(R.id.signup_hLocation_layout);
        signupSpecializationLayout=(TextInputLayout)inflate.findViewById(R.id.signup_specialization_layout);
        signupHnameEdittext=(AppCompatEditText) inflate.findViewById(R.id.signup_hname_editetxt);
        signupHcodeEdittext=(AppCompatEditText)inflate.findViewById(R.id.signup_hcode_edittext);
        signupHlocationEdittext=(AppCompatEditText)inflate.findViewById(R.id.signup_hLocation_Edittext);
        signupSpecializationEdittext=(AppCompatEditText)inflate.findViewById(R.id.signup_specialization_edittext);

        //----------edittext counter handling-----
        signupHnameLayout.setCounterEnabled(true);
        signupHnameLayout.setCounterMaxLength(25);

        signupHcodeLayout.setCounterEnabled(true);
        signupHcodeLayout.setCounterMaxLength(6);

        signupHlocationLayout.setCounterEnabled(true);
        signupHlocationLayout.setCounterMaxLength(30);

        signupSpecializationLayout.setCounterEnabled(true);
        signupSpecializationLayout.setCounterMaxLength(25);


        doc_details_btn=(AppCompatButton)inflate.findViewById(R.id.signup_doct_details_btn);
        doc_details_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String hname = signupHnameEdittext.getText().toString();
                String hcode = signupHcodeEdittext.getText().toString();
                String hloc = signupHlocationEdittext.getText().toString();
                String hsp = signupSpecializationEdittext.getText().toString();
                if (validate()) {
                    signup_doc_2.putString("HNAME", hname);
                    signup_doc_2.putString("HCODE", hcode);
                    signup_doc_2.putString("HLOC", hloc);
                    signup_doc_2.putString("HSP", hsp);

                    signup_part2 signupPart2 = new signup_part2();
                    signupPart2.setArguments(signup_doc_2);
                    FragmentManager fragmentManager = getFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.fragment_container, signupPart2);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                }
            }
        });

        return inflate;
    }

    private boolean validate() {
        if(signupHnameEdittext.getText().toString().isEmpty() ||
        signupHcodeEdittext.getText().toString().isEmpty() ||
                signupHlocationEdittext.getText().toString().isEmpty()||
               signupSpecializationEdittext.getText().toString().isEmpty())
        {
            alertDialog.setMessage("All fields are required");
            alertDialog.show();
            return false;
        }else{
            return true;
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


    }
}
