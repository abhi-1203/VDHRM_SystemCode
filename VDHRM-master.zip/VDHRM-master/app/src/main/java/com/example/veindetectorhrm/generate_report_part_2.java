package com.example.veindetectorhrm;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;



public class generate_report_part_2 extends Fragment {

   AppCompatButton generate_btn2;
    AppCompatEditText age,problem,desc;
    AlertDialog alertDialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_generate_report_part_2, container, false);
        age=(AppCompatEditText)view.findViewById(R.id.age_edittext);
        problem=(AppCompatEditText)view.findViewById(R.id.problem_edittext);
        desc=(AppCompatEditText)view.findViewById(R.id.desc);
        alertDialog = new AlertDialog.Builder(getActivity()).create();
        Bundle generated_details= this.getArguments();

    generate_btn2=(AppCompatButton)view.findViewById(R.id.generate_part2_btn);
    generate_btn2.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(age.getText().toString().isEmpty() ||
            problem.getText().toString().isEmpty() ||
            desc.getText().toString().isEmpty()){
                alertDialog.setTitle("Error");
                alertDialog.setMessage("All fields are required");
                alertDialog.show();
            }
            else{
                try {
                    SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getContext());
                     String docID = preferences.getString("uid"," ");
                    String type ="generateReport";
                    String pname =generated_details.getString("PNAME");
                    String pphone = generated_details.getString("PPHONE");
                    int tch =  generated_details.getInt("TCH");
                    String pemail = generated_details.getString("PEMAIL");
                    String page = age.getText().toString();
                    String pproblem = problem.getText().toString();
                    String pdesc = desc.getText().toString();
                    generateReport genRe = new generateReport(getContext());
                    genRe.execute(type, docID,pemail,pname,pphone,page,Integer.toString(tch),pproblem,pdesc);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
            FragmentManager fragmentManager = getFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.homepage_frame_container,new generate_report_part_1());
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();

        }
    });

    return view;
    }
}
