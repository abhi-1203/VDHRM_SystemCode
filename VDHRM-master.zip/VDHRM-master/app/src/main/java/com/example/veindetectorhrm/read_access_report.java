package com.example.veindetectorhrm;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.amazonaws.AmazonClientException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobile.client.Callback;
import com.amazonaws.mobile.client.UserStateDetails;
import com.amazonaws.mobileconnectors.s3.transfermanager.MultipleFileDownload;
import com.amazonaws.mobileconnectors.s3.transfermanager.TransferManager;
import com.amazonaws.mobileconnectors.s3.transfermanager.TransferManagerConfiguration;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;

import com.amazonaws.AmazonServiceException;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.concurrent.ExecutionException;

import static android.support.v4.content.PermissionChecker.checkSelfPermission;


public class read_access_report extends Fragment {
    String ACCESS_KEY = "AKIAQLYF2RPO4ZB4WXT7";
    String SECRET_KEY = "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";
    String bucketName = "s3veinbucket145218-dev";
    String keyName ;
    private ListView listView;

    private ProgressDialog Dialog ;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        int SDK_INT = android.os.Build.VERSION.SDK_INT;
        if (SDK_INT > 8) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                    .permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }
        View view = inflater.inflate(R.layout.fragment_read_access_report, container, false);

       File dir = new File(Environment.getExternalStorageDirectory(),"reports");
       if(dir.exists()) {
           Log.d("f","file exits"+dir.getAbsolutePath());
           deleteRecursive(dir);
        }

       Bundle info = this.getArguments();
       if(info.getString("phone") == "nothing" ) {
           SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getActivity());
           keyName = preferences.getString("uphone", " ");
       }else{
           keyName = info.getString("phone");
       }
        reportTask reportTask = new reportTask(getActivity(),view);
        reportTask.execute(keyName);
        return view;
    }

    private void deleteRecursive(File dir) {
        if (dir.isDirectory())
            for (File child : dir.listFiles())
                deleteRecursive(child);

        dir.delete();
    }


    public void  addlist(View v,Context context,String keyName)
    {
       AlertDialog alertDialog =  new AlertDialog.Builder(context).create();
        File dir = new File(Environment.getExternalStorageDirectory(),"reports/"+ keyName);
        if(dir.exists()) {
            File[] filelist = dir.listFiles();
            if (filelist.length != 0) {
                String[] NamesOfFiles = new String[filelist.length];
                for (int i = 0; i < NamesOfFiles.length; i++) {
                    NamesOfFiles[i] = filelist[i].getName();
                }
                listView = (ListView) v.findViewById(R.id.report_list_view);
                ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(context, R.layout.file_text_view, NamesOfFiles);
                listView.setAdapter(arrayAdapter);
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        String item = (String) listView.getItemAtPosition(position);
                        Toast.makeText(context, item, Toast.LENGTH_LONG).show();
                        try {
                            File file = new File(Environment.getExternalStorageDirectory() , "/reports/"+keyName+"/"+item);
                            Log.d("path",file.getPath());
                            Intent intent = new Intent(Intent.ACTION_VIEW);
                            Uri data = FileProvider.getUriForFile(context, BuildConfig.APPLICATION_ID + ".provider", file);
                            intent.setDataAndType(data, "application/pdf");
                            intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            context.startActivity(intent);


                        } catch (Exception e) {
                            Toast.makeText(context, e.getLocalizedMessage(), Toast.LENGTH_LONG).show();
                            Log.d("openingerror", e.getMessage());
                        }

                    }
                });
            } else {
                alertDialog.setMessage("No records found");
                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent = new Intent(context, Homepage.class);
                            context.startActivity(intent);
                    }
                });
                alertDialog.show();
            }
        }else{
            alertDialog.setMessage("No records found");
            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(context, Homepage.class);
                        context.startActivity(intent);
                    }

            });
            alertDialog.show();

        }
    }

}


