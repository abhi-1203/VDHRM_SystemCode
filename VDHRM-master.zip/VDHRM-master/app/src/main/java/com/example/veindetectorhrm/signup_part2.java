package com.example.veindetectorhrm;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class signup_part2 extends Fragment {
    private ProgressDialog Dialog ;
    AlertDialog alertDialog;
    AppCompatButton signup_btn;
    AppCompatEditText signupPasswordEdittext, signupCpasswordEditetxt;
    TextInputLayout signupPasswordLayout, signupCpasswordLayout;
    Context context = this.getContext();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_signup_part2, container, false);
        alertDialog = new AlertDialog.Builder(getActivity()).create();

        Bundle signup_final = this.getArguments();
        //---object referencing---
        signupPasswordEdittext = (AppCompatEditText) view.findViewById(R.id.singup_password_editetxt);
        signupCpasswordEditetxt = (AppCompatEditText) view.findViewById(R.id.signup_cpassword_edittext);
        signupPasswordLayout = (TextInputLayout) view.findViewById(R.id.singup_password_layout);
        signupCpasswordLayout = (TextInputLayout) view.findViewById(R.id.signup_cpassword_layout);

        //---edittext counter handling----

        signupPasswordLayout.setCounterEnabled(true);
        signupPasswordLayout.setCounterMaxLength(10);
        signupCpasswordLayout.setCounterEnabled(true);
        signupCpasswordLayout.setCounterMaxLength(10);

        signup_btn = (AppCompatButton) view.findViewById(R.id.signup_btn1);

        signup_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password = signupPasswordEdittext.getText().toString();
                String cpassword = signupCpasswordEditetxt.getText().toString();
                if (password.isEmpty()) {
                    alertDialog.setTitle("Error");
                    alertDialog.setMessage("Enter Password");
                    alertDialog.show();

                } else if (cpassword.isEmpty()) {
                    alertDialog.setTitle("Error");
                    alertDialog.setMessage("Both fields are necessary");
                    alertDialog.show();
                } else if (!password.equals(cpassword)) {
                    alertDialog.setTitle("Error");
                    alertDialog.setMessage("passwords are not same");
                    alertDialog.show();
                } else {
                    SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getContext());
                    int role = preferences.getInt("role", 0);
                    String type = "register";
                    DBClass dbObj = new DBClass(getActivity());
                    if (role == 1) {
                        if (signup_final != null) {
                            String username = signup_final.getString("username");
                            String uemail = signup_final.getString("useremail");
                            String uphone = signup_final.getString("userphone");
                            String UType = "0";
                            dbObj.execute(type, username, password, uemail, uphone, UType);
                        } else {
                            alertDialog.setMessage("bundle empty");
                            alertDialog.show();
                        }
                    } else if (role == 2) {
                        if (signup_final != null) {
                            String username = signup_final.getString("username");
                            String uemail = signup_final.getString("useremail");
                            String uphone = signup_final.getString("userphone");
                            String UType = "1";
                            String hname = signup_final.getString("HNAME");
                            String hcode = signup_final.getString("HCODE");
                            String hloc = signup_final.getString("HLOC");
                            String spec = signup_final.getString("HSP");
                            Log.d("usdet","details: "+hname+" "+hcode+hloc+spec+username+uemail+uphone+UType);
                            dbObj.execute(type,username,password,uemail,uphone,UType,hname,hloc,hcode,spec);


                        }else {
                            Log.d("usdet","inside in else condition");
                            alertDialog.setMessage("bundle empty");
                            alertDialog.show();
                        }

                    }
                }
            }
        });


        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

}
