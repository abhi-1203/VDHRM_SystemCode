package com.example.veindetectorhrm;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.WindowManager;
import android.widget.ProgressBar;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class DBClass extends AsyncTask<String, Void, String> {
    Context context;
    AlertDialog alertDialog;
    private ProgressDialog Dialog;

    public DBClass(Context context) {
        this.context = context;
    }
    @SuppressLint("WrongThread")
    @Override
    protected String doInBackground(String... params) {

        String type = params[0];
        String login_url = "https://vdhrm.000webhostapp.com/login.php";
        String register_url = "https://vdhrm.000webhostapp.com/userRegister.php";

        String response = null;
        if (type.equals("login")) {
            try {
                String uname = params[1];
                String upass = params[2];

                URL url = new URL(login_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, StandardCharsets.UTF_8));
                String post_data = URLEncoder.encode("uID", "UTF-8") + "=" + URLEncoder.encode(uname, "UTF-8") + "&"
                        + URLEncoder.encode("upass", "UTF-8") + "=" + URLEncoder.encode(upass, "UTF-8");

                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.ISO_8859_1));

                StringBuilder sb = new StringBuilder();
                for (int c; (c = bufferedReader.read()) >= 0; )
                    sb.append((char) c);
                response = sb.toString();
                Log.d("tag", "response from json: " + response);
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                JSONObject myResponse = new JSONObject(response.toString());
                 if (myResponse.get("status").equals("200")) {
                    Log.d("tag", "result after Reading JSON Response");
                    Log.d("tag", "U_ID: " + myResponse.getString("uID"));
                    Log.d("tag", "Type: " + myResponse.getString("Type"));
                    Log.d("tag", "Email: " + myResponse.getString("email"));
                    Log.d("tag", "PhoneNum: " + myResponse.getString("phoneNumber"));
                    Log.d("tag", "Name: " + myResponse.getString("fname") + " " + myResponse.getString("lname"));

                }

            } catch (MalformedURLException e) {
                Log.d("url", "url not found.");
                e.printStackTrace();
            } catch (IOException e) {
                Log.d("url", "Connection cannot be performed. url cannot be opened.");
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return response;

        } else if (type.equals("register")) {
            try {
                String post_data = null;
                String FName = params[1];
                String uPass = params[2];
                String uEmail = params[3];
                String uPhoneNum = params[4];
                String UType = params[5];

                URL url = new URL(register_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, StandardCharsets.UTF_8));

                if (UType.equals("0")) {
                    post_data = URLEncoder.encode("FName", "UTF-8") + "=" + URLEncoder.encode(FName, "UTF-8") + "&"
                            + URLEncoder.encode("uPass", "UTF-8") + "=" + URLEncoder.encode(uPass, "UTF-8") + "&"
                            + URLEncoder.encode("uEmail", "UTF-8") + "=" + URLEncoder.encode(uEmail, "UTF-8") + "&"
                            + URLEncoder.encode("uPhoneNum", "UTF-8") + "=" + URLEncoder.encode(uPhoneNum, "UTF-8") + "&"
                            + URLEncoder.encode("UType", "UTF-8") + "=" + URLEncoder.encode(UType, "UTF-8");
                } else if (UType.equals("1")) {
                    String hname = params[6];
                    String hloc = params[7];
                    String hcode = params[8];
                    String spec = params[9];
                    post_data = URLEncoder.encode("FName", "UTF-8") + "=" + URLEncoder.encode(FName, "UTF-8") + "&"
                            + URLEncoder.encode("uPass", "UTF-8") + "=" + URLEncoder.encode(uPass, "UTF-8") + "&"
                            + URLEncoder.encode("uEmail", "UTF-8") + "=" + URLEncoder.encode(uEmail, "UTF-8") + "&"
                            + URLEncoder.encode("uPhoneNum", "UTF-8") + "=" + URLEncoder.encode(uPhoneNum, "UTF-8") + "&"
                            + URLEncoder.encode("UType", "UTF-8") + "=" + URLEncoder.encode(UType, "UTF-8") + "&"
                            + URLEncoder.encode("HName", "UTF-8") + "=" + URLEncoder.encode(hname, "UTF-8") + "&"
                            + URLEncoder.encode("Hlocation", "UTF-8") + "=" + URLEncoder.encode(hloc, "UTF-8") + "&"
                            + URLEncoder.encode("Hcode", "UTF-8") + "=" + URLEncoder.encode(hcode, "UTF-8") + "&"
                            + URLEncoder.encode("Doc_sp", "UTF-8") + "=" + URLEncoder.encode(spec, "UTF-8");
                }
                if (post_data != null) {
                    bufferedWriter.write(post_data);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    outputStream.close();
                    InputStream inputStream = httpURLConnection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.ISO_8859_1));

                    StringBuilder sb = new StringBuilder();
                    for (int c; (c = bufferedReader.read()) >= 0; )
                        sb.append((char) c);
                    response = sb.toString();
                    Log.d("tag", "response from json: " + response);
                    bufferedReader.close();
                    inputStream.close();
                    httpURLConnection.disconnect();
                    JSONObject myResponse = new JSONObject(response.toString());
                   if (myResponse.getString("status").equals("200")) {
                        Log.d("tag", "result after Reading JSON Response");
                        //Log.d("tag","url- "+myResponse.getString("url"))
                        Log.d("tag", "U_ID: " + myResponse.getString("uID"));
                        Log.d("tag", "Type: " + myResponse.getString("Type"));
                        Log.d("tag", "Email: " + myResponse.getString("email"));
                        Log.d("tag", "PhoneNum: " + myResponse.getString("phoneNumber"));
                        Log.d("tag", "Name: " + myResponse.getString("fname") + " " + myResponse.getString("lname"));
                        Log.d("tag", "Register Successful");
                        createfolderTask createfolderTask= new createfolderTask(context);
                        createfolderTask.execute(myResponse.getString("phoneNumber"));
                    }
                } else {
                    Log.d("err", "post data is null");
                }
            } catch (MalformedURLException e) {
                Log.d("url", "url not found.");
                e.printStackTrace();
            } catch (IOException e) {
                Log.d("url", "Connection cannot be performed. url cannot be opened.");
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return response;
        }
        return null;
    }

    @Override
    protected void onPreExecute() {
        Dialog = new ProgressDialog(context);
        Dialog.setMessage("Just a minute....");
        Dialog.setIndeterminate(false);
        Dialog.setCancelable(false);
        Dialog.show();

        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(String response) {
        Log.d("url", "res: " + response);
        if (response != null) {
            try {
                JSONObject myResponse = new JSONObject(response.toString());
                if (myResponse.getString("status").equals("200")) {
                    SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putString("uname", myResponse.getString("fname"));
                    editor.putString("uemail", myResponse.getString("email"));
                    editor.putString("uphone", myResponse.getString("phoneNumber"));
                    editor.putString("utype", myResponse.getString("Type"));
                    editor.putString("uid", myResponse.getString("uID"));
                    editor.commit();

                    Intent intent = new Intent(context, Homepage.class);
                       context.startActivity(intent);
                       Dialog.dismiss();
               }
            else {
                    Dialog.dismiss();
                    alertDialog = new AlertDialog.Builder(context).create();
                    alertDialog.setMessage(myResponse.getString("message"));
                    alertDialog.show();
                }
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
        } else {
            Dialog.dismiss();
        }
        super.onPostExecute(response);

    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }



}
