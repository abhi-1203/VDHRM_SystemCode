package com.example.veindetectorhrm;

import android.content.Context;
import android.os.AsyncTask;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

public class createfolderTask extends AsyncTask<String,Void,String> {
    private Context context;


    public createfolderTask(Context context) {
        this.context = context;
    }

    @Override
    protected String doInBackground(String... strings) {
        String SUFFIX="/";
        String phone_key = strings[0];
        String ACCESS_KEY = "AKIAQLYF2RPO4ZB4WXT7";
        String SECRET_KEY = "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";
        String bucketName = "s3veinbucket145218-dev";
        AWSCredentials credentials = new BasicAWSCredentials(ACCESS_KEY, SECRET_KEY);
        AmazonS3 s3client = new AmazonS3Client(credentials);

        // create meta-data for your folder and set content-length to 0
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentLength(0);

        // create empty content
        InputStream emptyContent = new ByteArrayInputStream(new byte[0]);

        PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName,
                phone_key + SUFFIX, emptyContent, metadata);

        // send request to S3 to create folder
        s3client.putObject(putObjectRequest);
        return null;
    }
}

