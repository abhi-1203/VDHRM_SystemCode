package com.example.veindetectorhrm;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;


public class fileHandler extends Activity {
    private static final int PERMISSION_REQUEST_CODE = 1;
    private final String TAG = "BLUETOOTH";
    private BluetoothAdapter bluetoothAdapter;
    private Context bctx;
    int RequestCode = 1;
    static final int ST_LISTENING=1;
    static final int ST_Connecting=2;
    static final int ST_connected=3;
    static final int ST_connection_failed=4;
    static final int ST_msg_received=5;
    private String globalmsg="";
    private static final String APP_NAME= "VDHRM";
    private static final UUID my_UUID = UUID.fromString("6fd729af-5af3-4238-8f29-5480e0b732fe");

    TextView dis;
    AlertDialog alertDialog;
    private List<BluetoothDevice> issues = new ArrayList<BluetoothDevice>();
    BluetoothDevice mmDevice = null;
    private SingBroadcastReceiver mReceiver;
    fileHandler(Context context) {
        bctx = context;
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        bctx.getSystemService(Context.BLUETOOTH_SERVICE);
    }

    boolean BTon() {
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Log.d("BLUETOOTHERROR", "Cannot use Bluetooth.");
        }
        if (bluetoothAdapter.isEnabled()) {
            bluetoothAdapter.disable();
            Log.d("BLUESTATE", "BT is off");
        }

        if (!bluetoothAdapter.isEnabled()) {
            //Intent enableBTIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            //startActivityForResult(enableBTIntent,RequestCode);
            bluetoothAdapter.enable();
            Log.d("BLUESTATE", "BT is on");
            return true;
        }

        return false;
    }

    @Override
    protected void onActivityResult(int requestcode, int resultCode, Intent data) {
        if (requestcode == RequestCode) {
            if (resultCode == RESULT_OK) {
                Log.d("BLUESTATE", "BT is enabled.");
            } else if (resultCode == RESULT_CANCELED) {
                Log.d("BLUESTATE", "BT is enable canceled.");
            }
        }
    }


    public void listPaired(String message){
        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        String[] strings= new String[pairedDevices.size()];
        int index=0;
        if (pairedDevices.size() > 0) {
            for (BluetoothDevice device : pairedDevices) {
                strings[index]= device.getName();
                //Log.d("BT", strings[index]);
                index++;
                if (device.getName().equals("pi")) //Note, you will need to change this to match the name of your device
                {
                    Log.d("Aquarium", device.getName());
                    mmDevice = device;
                    ClientClass cc = new ClientClass(mmDevice,message);
                    cc.start();
                    Log.d("BT", "Connecting");
                    break;
                } else {
                    Log.d("BT", "Not Paired, searching for devices...");
                    scan(message);
                }
            }
        }
    }


public void scan(String message){
        globalmsg=message;
        alertDialog= new AlertDialog.Builder(bctx).create();
    alertDialog.setTitle("Devices");

    mReceiver = new SingBroadcastReceiver();
    IntentFilter intentFilter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
    bctx.registerReceiver(mReceiver, intentFilter);

    if (bluetoothAdapter.isDiscovering()) {
        bluetoothAdapter.cancelDiscovery();
    }
    bluetoothAdapter.startDiscovery();
}

private class ClientClass extends Thread{
        private BluetoothDevice device;
        private BluetoothSocket socket;
        String data="";
        public ClientClass(BluetoothDevice device1, String msg){
            device=device1;
            data=msg;
            try {
                socket=device.createRfcommSocketToServiceRecord(my_UUID);
            } catch (IOException e) {
                Log.d("BTD","cannot form connection");
                e.printStackTrace();
            }
        }
        public void run(){
            try {
                if(!socket.isConnected()){
                    socket.connect();
                    Log.d("BTD","Connected with pi");
                    SendReceive ss= new SendReceive(socket,data);
                    ss.start();
                }
            } catch (IOException e) {
                Log.d("BTD","Connection failed with pi");
                e.printStackTrace();
            }
        }
}

private class SendReceive extends Thread{
        private final BluetoothSocket bluetoothSocket;
        private final OutputStream outputStream;
        String dString="";
        public SendReceive(BluetoothSocket soc,String data){
            bluetoothSocket=soc;
            OutputStream tempout = null;
            dString=data;

            try {
                tempout =bluetoothSocket.getOutputStream();
            } catch (IOException e) {
                Log.d("BTD","outstream error in sendReceive");
                e.printStackTrace();
            }
            outputStream=tempout;
        }

        public void run() {
            ///byte[] buffer = new byte[1024];
            //int bytes;
            Log.d("BTSEND", "inside write()");
            if (outputStream != null){
                try {
                    Log.d("BTSEND", "inside try block");
                    outputStream.write(dString.getBytes());
                    Log.d("BTSEND", "data Sent success");
                } catch (IOException e) {
                    Log.d("BTSEND", "data Sent failed");
                    e.printStackTrace();
                }
        }else{
                Log.d("BTSEND","Outputstream is null.");
            }
        }

    }



    private class SingBroadcastReceiver extends BroadcastReceiver {

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction(); //may need to chain this to a recognizing function
            if (BluetoothDevice.ACTION_FOUND.equals(action)){
                // Get the BluetoothDevice object from the Intent
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                // Add the name and address to an array adapter to show in a Toast
                String derp = device.getName() + " - " + device.getAddress();
                Toast.makeText(bctx, derp, Toast.LENGTH_LONG).show();
                Log.d("BTD", "Device found: " + device.getName() + "; MAC " + device.getAddress());
                issues.add(device);

                if(device.getName().equals("pi")){
                    alertDialog.setMessage(device.getName());
                    alertDialog.show();
                    Log.d("BTD","pi identified. connecting to it.");
                    ClientClass cc = new ClientClass(device,globalmsg);
                    cc.start();
                }
                Log.d("BTD",issues.toString());
            }
        }
    }




    /*protected void DestroyBT() {
        // Don't forget to unregister the ACTION_FOUND receiver.
        bctx.unregisterReceiver(broadcastReceiver);
    }*/
}
