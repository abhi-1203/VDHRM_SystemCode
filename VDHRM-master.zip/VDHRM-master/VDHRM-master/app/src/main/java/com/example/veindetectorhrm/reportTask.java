package com.example.veindetectorhrm;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;
import android.view.View;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.mobileconnectors.s3.transfermanager.MultipleFileDownload;
import com.amazonaws.mobileconnectors.s3.transfermanager.TransferManager;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;

import java.io.File;

public class reportTask extends AsyncTask<String,Void,String> {
    View view;
    Context context;
    String keyName;
    String ACCESS_KEY = "AKIAQLYF2RPO4ZB4WXT7";
    String SECRET_KEY = "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";
    String bucketName = "s3veinbucket145218-dev";
    private ProgressDialog Dialog ;

    @Override
    protected void onPreExecute() {
        Dialog.setMessage("This can take a few sec..please wait!!");
        Dialog.setIndeterminate(false);
        Dialog.setCancelable(false);
        Dialog.show();
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(String o) {
        Dialog.dismiss();
        read_access_report r= new  read_access_report();
        r.addlist(view,context,keyName);
        super.onPostExecute(o);
    }

    public reportTask(Context context,View view){
        this.view=view;
        this.context = context;
        this.Dialog = new ProgressDialog(context);
    }


    @Override
    protected String doInBackground(String...strings) {
        keyName = strings[0];

        File directory = new File(Environment.getExternalStorageDirectory(),"reports");
        directory.mkdirs();
        AWSCredentials credentials = new BasicAWSCredentials(ACCESS_KEY, SECRET_KEY);
        AmazonS3 s3client = new AmazonS3Client(credentials);
        TransferManager transferManager = new TransferManager(s3client);
        MultipleFileDownload download = transferManager.downloadDirectory(bucketName, keyName, directory);

        try {
            download.waitForCompletion();
            Log.d("success", "downloaded successfully");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return null;
    }
}
