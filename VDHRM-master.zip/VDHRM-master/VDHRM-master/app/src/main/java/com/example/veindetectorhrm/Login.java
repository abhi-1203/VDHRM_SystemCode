package com.example.veindetectorhrm;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class Login extends AppCompatActivity {
    public static Context contextOfLogin;
    AlertDialog alertDialog;
    AppCompatButton loginButton;
    TextInputLayout usernameLayout, passwordLayout;
    AppCompatEditText usernameEdittext, passwordEdittext;
    Context context;
    private ProgressDialog Dialog;
    int backbutton = 0;
    private BluetoothAdapter bluetoothAdapter;


    @Override
    public void onBackPressed() {
        if (backbutton >= 1) {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

        } else {
            Toast.makeText(Login.this, "Press the back button once again to close app", Toast.LENGTH_SHORT).show();
            backbutton++;
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);

        //Bluetooth Code
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if (!bluetoothAdapter.isEnabled()) {
            //Intent enableBTIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            //startActivityForResult(enableBTIntent,RequestCode);
            bluetoothAdapter.enable();
            Log.d("BLUESTATE", "BT is on");
        }


        if (android.os.Build.VERSION.SDK_INT > 9) {

            StrictMode.ThreadPolicy policy = new
                    StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);

        }


        alertDialog = new AlertDialog.Builder(Login.this).create();

        //---object reference--
        loginButton = (AppCompatButton) findViewById(R.id.login_btn);
        usernameLayout = (TextInputLayout) findViewById(R.id.login_username_layout);
        passwordLayout = (TextInputLayout) findViewById(R.id.login_password_layout);
        usernameEdittext = (AppCompatEditText) findViewById(R.id.login_username_edittext);
        passwordEdittext = (AppCompatEditText) findViewById(R.id.login_password_edittext);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (usernameEdittext.getText().toString().isEmpty()) {
                    alertDialog.setTitle("Error");
                    alertDialog.setMessage("Enter Username");
                    alertDialog.show();
                    usernameEdittext.requestFocus();
                }
                else if (passwordEdittext.getText().toString().isEmpty()) {
                    alertDialog.setTitle("Error");
                    alertDialog.setMessage("Enter Password");
                    alertDialog.show();
                    passwordEdittext.requestFocus();
                } else {

                    String type = "login";
                    String userName = usernameEdittext.getText().toString();
                    String password = passwordEdittext.getText().toString();
                    DBClass dbObj = new DBClass(Login.this);
                    dbObj.execute(type, userName, password);
                }
            }
        });
    }

    public void signup(View view) {
        startActivity(new Intent(Login.this, Signup.class));
    }



}



