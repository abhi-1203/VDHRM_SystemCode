package com.example.veindetectorhrm;

import android.app.AlertDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;


public class generate_report_part_1 extends Fragment {
    AppCompatButton generate_btn1;
    AppCompatEditText pname, pphonenum,pemail;
    Spinner tcheckup;
    AlertDialog alertDialog;
    private static final String[] checkup_types = {"Vein Detection", "HRM","Both"};
    int selected=100;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_generate_report_part_1, container, false);
        pname = (AppCompatEditText) view.findViewById(R.id.patientname_edittext);
        pphonenum = (AppCompatEditText) view.findViewById(R.id.patientphne_edittext);
        tcheckup = (Spinner) view.findViewById(R.id.spinner_typeOfcheck);
        pemail =(AppCompatEditText)view.findViewById(R.id.patientmail_edittext);
        alertDialog = new AlertDialog.Builder(getActivity()).create();

        //spinner initialization

        ArrayAdapter<String> adapter_option=new ArrayAdapter<String>(this.getActivity(),android.R.layout.simple_spinner_item,checkup_types);
        adapter_option.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        tcheckup.setAdapter(adapter_option);
        tcheckup.setPrompt("Select a role");


        //---spinner handler---
        tcheckup.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(checkup_types[i] == "Vein Detection"){
                    selected = 0;
                }else if(checkup_types[i] == "HRM"){
                    selected = 1;
                }else if(checkup_types[i] == "Both"){
                    selected = 2;
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        generate_btn1 = (AppCompatButton) view.findViewById(R.id.generate_part1_btn);
        generate_btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String p_name = pname.getText().toString();
                String p_phone = pphonenum.getText().toString();

                if ( pname.getText().toString().isEmpty() || pphonenum.getText().toString().isEmpty()  ||
                        selected ==100){
                    alertDialog.setTitle("Error");
                    alertDialog.setMessage("All fields are required");
                    alertDialog.show();
                }else  if(pphonenum.getText().toString().length() != 10){
                    alertDialog.setTitle("Error");
                    alertDialog.setMessage("Phone Number should consist 10 digits only");
                    alertDialog.show();
                }
                else {
                    Bundle generate_report = new Bundle();
                    generate_report.putString("PNAME", p_name);
                    generate_report.putString("PPHONE", p_phone);
                    generate_report.putInt("TCH", selected);
                    if(!pemail.getText().toString().isEmpty()){
                        generate_report.putString("PEMAIL",pemail.getText().toString());
                    }else{
                        generate_report.putString("PEMAIL",null);
                    }
                    generate_report_part_2 generate_report_part2 = new generate_report_part_2();
                    generate_report_part2.setArguments(generate_report);
                    FragmentManager fragmentManager = getFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.homepage_frame_container, generate_report_part2);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                }

            }
        });
        return view;
    }
}
