package com.example.veindetectorhrm;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.support.v7.*;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;


public class Homepage extends AppCompatActivity implements  NavigationView.OnNavigationItemSelectedListener, BottomNavigationView.OnNavigationItemSelectedListener {
    String uname,uemail,uid,uphonenumber,utype;
    Toolbar toolbar;
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    BottomNavigationView bottomNavigationView;
    TextView name;
    int backbutton=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
       //---getting  details----
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
       uname = preferences.getString("uname"," ");
       utype=preferences.getString("utype"," ");

        Toast.makeText(this,uname,Toast.LENGTH_LONG).show();

        //fragment initialiasation------------------------
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.homepage_frame_container, new home());
        fragmentTransaction.commit();
        bottomNavigationView = (BottomNavigationView)findViewById(R.id.btm_nav);
        bottomNavigationView.setSelectedItemId(R.id.home_menu);
        switch (utype){
            case "0": {
                bottomNavigationView.inflateMenu(R.menu.bottom_nav_menu);
                break;
            }
            case "1": {
                bottomNavigationView.inflateMenu(R.menu.doctor_bottom_nav_menu);
                break;
            }
        }
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                int id = menuItem.getItemId();
                switch (id) {
                    case R.id.home_menu:
                    case R.id.doc_home_menu: {
                        FragmentManager fragmentManager = getSupportFragmentManager();
                        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                        fragmentTransaction.replace(R.id.homepage_frame_container, new home());
                        fragmentTransaction.commit();
                        break;
                    }
                    case R.id.read_access_menu:
                    {
                        read_access_request readAccessRequest1 = new read_access_request();
                        FragmentManager fragmentManager = getSupportFragmentManager();
                        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                        fragmentTransaction.replace(R.id.homepage_frame_container,readAccessRequest1);
                        fragmentTransaction.commit();
                        break;
                    }
                    case R.id.contact_us_menu:
                    case R.id.doc_contact_us_menu: {
                        FragmentManager fragmentManager = getSupportFragmentManager();
                        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                        fragmentTransaction.replace(R.id.homepage_frame_container, new contact_us());
                        fragmentTransaction.commit();
                        break;
                    }
                    case R.id.doc_read_access_menu:
                    {
                        Bundle info = new Bundle();
                        info.putString("role","doctor");
                        read_access_request readAccessRequest = new read_access_request();
                        readAccessRequest.setArguments(info);
                        FragmentManager fragmentManager = getSupportFragmentManager();
                        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                        fragmentTransaction.replace(R.id.homepage_frame_container, readAccessRequest);
                        fragmentTransaction.commit();
                        break;
                    }
                    case R.id.doc_generate_menu:
                    {
                        FragmentManager fragmentManager = getSupportFragmentManager();
                        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                        fragmentTransaction.replace(R.id.homepage_frame_container, new generate_report_part_1());
                        fragmentTransaction.commit();
                        break;

                    }
                }
                return true;
            }
        });

        //---------------------------
        toolbar=(Toolbar)findViewById(R.id.toolbar_homepage);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Vein Detector & HRM");


        //navigration view setup

        drawerLayout=(DrawerLayout)findViewById(R.id.drawer_layout);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        View header = navigationView.getHeaderView(0);
        android.support.v7.app.ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        name =(TextView)header.findViewById(R.id.nav_name);
        name.setText(uname);


    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            if(backbutton >= 1)
            {
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }
            else
            {
                Toast.makeText(Homepage.this,"Press the back button once again to close app",Toast.LENGTH_SHORT).show();
                backbutton++;
            }

        }
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        int id= menuItem.getItemId();
        switch (id){
            case R.id.settings_menu:
            {

                Toast.makeText(this, " Account settings", Toast.LENGTH_SHORT).show();
                break;

            }
            case R.id.aboutus_menu:
            {
                Toast.makeText(this, "About Us", Toast.LENGTH_SHORT).show();
                break;


            }
            case R.id.share_menu:
            {
                Toast.makeText(this, "Share", Toast.LENGTH_SHORT).show();
                break;

            }
            case R.id.logout_menu:
            {
                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                SharedPreferences.Editor editor = preferences.edit();
                editor.clear();
                editor.commit();
                Toast.makeText(this, " Logout", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Homepage.this, Login.class));
                break;

            }
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;

    }
}
